package com.example.crud.dto;

import lombok.Builder;

@Builder
public record LoginSaida(String token) {

}
