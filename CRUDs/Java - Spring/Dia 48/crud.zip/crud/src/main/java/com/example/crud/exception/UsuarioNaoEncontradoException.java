package com.example.crud.exception;

public class UsuarioNaoEncontradoException extends RuntimeException{
	public UsuarioNaoEncontradoException() {
		super("Usuario não encontrado.");
	}
}
